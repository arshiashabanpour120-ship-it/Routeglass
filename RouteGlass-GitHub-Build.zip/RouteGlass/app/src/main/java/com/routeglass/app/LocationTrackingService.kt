package com.routeglass.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.google.android.gms.location.*
import android.location.Location

class LocationTrackingService : Service() {
    private lateinit var fused: FusedLocationProviderClient
    private var startedAt = 0L
    private var lastPoint: TrackPoint? = null
    private var distanceMeters = 0.0
    private var paused = false

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            if (paused) return
            result.locations.forEach { loc ->
                if (!loc.hasAccuracy() || loc.accuracy > 60f) return@forEach
                val p = TrackPoint(loc.latitude, loc.longitude, System.currentTimeMillis(), loc.speed)
                lastPoint?.let { prev ->
                    val a = Location("prev").apply { latitude=prev.lat; longitude=prev.lon }
                    val b = Location("now").apply { latitude=p.lat; longitude=p.lon }
                    val d = a.distanceTo(b)
                    if (d in 2f..500f) distanceMeters += d
                }
                lastPoint = p
                RouteStore.addPoint(this@LocationTrackingService, p)
                sendBroadcast(Intent(ACTION_UPDATE).setPackage(packageName).putExtra("distance", distanceMeters).putExtra("speed", p.speed))
            }
        }
    }

    override fun onCreate() { super.onCreate(); fused = LocationServices.getFusedLocationProviderClient(this) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startTracking()
            ACTION_PAUSE -> paused = true
            ACTION_RESUME -> paused = false
            ACTION_STOP -> stopTracking()
        }
        return START_STICKY
    }

    private fun startTracking() {
        if (startedAt == 0L) startedAt = System.currentTimeMillis()
        createChannel()
        val n = notification("در حال ثبت مسیر شما")
        if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION) else startForeground(7, n)
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000L).setMinUpdateDistanceMeters(5f).setWaitForAccurateLocation(false).build()
        try { fused.requestLocationUpdates(req, callback, mainLooper) } catch (_: SecurityException) { stopSelf() }
    }

    private fun stopTracking() {
        fused.removeLocationUpdates(callback)
        val pts = RouteStore.activePoints(this)
        if (pts.isNotEmpty()) RouteStore.saveRoute(this, startedAt.takeIf { it > 0 } ?: pts.first().time, System.currentTimeMillis(), distanceMeters, pts)
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("routeglass_tracking", "Route tracking", NotificationManager.IMPORTANCE_LOW))
        }
    }
    private fun notification(message: String): Notification {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "routeglass_tracking") else Notification.Builder(this)
        return b.setContentTitle("RouteGlass").setContentText(message).setSmallIcon(android.R.drawable.ic_menu_mylocation).setOngoing(true).build()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.routeglass.START"
        const val ACTION_PAUSE = "com.routeglass.PAUSE"
        const val ACTION_RESUME = "com.routeglass.RESUME"
        const val ACTION_STOP = "com.routeglass.STOP"
        const val ACTION_UPDATE = "com.routeglass.UPDATE"
    }
}
