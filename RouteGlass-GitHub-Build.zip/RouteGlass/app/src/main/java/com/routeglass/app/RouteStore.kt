package com.routeglass.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class TrackPoint(val lat: Double, val lon: Double, val time: Long, val speed: Float)

data class SavedRoute(val id: Long, val started: Long, val ended: Long, val distance: Double, val points: List<TrackPoint>)

object RouteStore {
    private const val PREF = "routeglass_store"
    private const val ACTIVE = "active_points"
    private const val ROUTES = "routes"

    fun addPoint(context: Context, point: TrackPoint) {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(ACTIVE, "[]"))
        arr.put(point.toJson())
        prefs.edit().putString(ACTIVE, arr.toString()).apply()
    }

    fun activePoints(context: Context): List<TrackPoint> = parse(context.getSharedPreferences(PREF, 0).getString(ACTIVE, "[]"))

    fun clearActive(context: Context) { context.getSharedPreferences(PREF, 0).edit().remove(ACTIVE).apply() }

    fun saveRoute(context: Context, started: Long, ended: Long, distance: Double, points: List<TrackPoint>) {
        val prefs = context.getSharedPreferences(PREF, 0)
        val arr = JSONArray(prefs.getString(ROUTES, "[]"))
        val item = JSONObject().put("id", ended).put("started", started).put("ended", ended).put("distance", distance)
        val pts = JSONArray(); points.forEach { pts.put(it.toJson()) }; item.put("points", pts)
        arr.put(item); prefs.edit().putString(ROUTES, arr.toString()).remove(ACTIVE).apply()
    }

    fun routes(context: Context): List<SavedRoute> {
        val arr = JSONArray(context.getSharedPreferences(PREF, 0).getString(ROUTES, "[]"))
        return (0 until arr.length()).mapNotNull { i -> runCatching {
            val o = arr.getJSONObject(i); SavedRoute(o.getLong("id"), o.getLong("started"), o.getLong("ended"), o.getDouble("distance"), parse(o.getJSONArray("points").toString()))
        }.getOrNull() }.reversed()
    }

    private fun TrackPoint.toJson() = JSONObject().put("lat", lat).put("lon", lon).put("time", time).put("speed", speed.toDouble())
    private fun parse(raw: String?): List<TrackPoint> {
        val arr = JSONArray(raw ?: "[]")
        return (0 until arr.length()).mapNotNull { i -> runCatching { val o=arr.getJSONObject(i); TrackPoint(o.getDouble("lat"),o.getDouble("lon"),o.getLong("time"),o.optDouble("speed",0.0).toFloat()) }.getOrNull() }
    }
}
