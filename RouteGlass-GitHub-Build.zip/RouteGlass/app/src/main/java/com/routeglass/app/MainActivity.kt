package com.routeglass.app

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polyline
import java.text.SimpleDateFormat
import java.util.*

private val Bg = Color(0xFF080D18)
private val Glass = Color(0x24FFFFFF)
private val Cyan = Color(0xFF74D7FF)

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val granted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true || result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            ContextCompat.startForegroundService(this, Intent(this, LocationTrackingService::class.java).setAction(LocationTrackingService.ACTION_START))
            sendBroadcast(Intent("com.routeglass.UI_STARTED").setPackage(packageName))
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        setContent { RouteGlassApp(::askPermissions) }
    }
    private fun askPermissions() {
        val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        permissionLauncher.launch(p.toTypedArray())
    }
}

@Composable
fun RouteGlassApp(requestPermissions: () -> Unit) {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var recording by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var distance by remember { mutableDoubleStateOf(0.0) }
    var speed by remember { mutableFloatStateOf(0f) }
    var points by remember { mutableStateOf(RouteStore.activePoints(context)) }
    var routes by remember { mutableStateOf(RouteStore.routes(context)) }

    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (i?.action == "com.routeglass.UI_STARTED") { recording = true; paused = false; return }
                distance = i?.getDoubleExtra("distance", distance) ?: distance
                speed = i?.getFloatExtra("speed", speed) ?: speed
                points = RouteStore.activePoints(context)
            }
        }
        ContextCompat.registerReceiver(context, receiver, IntentFilter().apply { addAction(LocationTrackingService.ACTION_UPDATE); addAction("com.routeglass.UI_STARTED") }, ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { runCatching { context.unregisterReceiver(receiver) } }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Color(0xFF141D2B), primary = Cyan)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF14243A), Bg, Color(0xFF080B12))))) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("ROUTEGLASS", color = Color.White.copy(.65f), fontSize = 11.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                        Text(if (tab == 0) "مسیر من" else if (tab == 1) "تاریخچه مسیرها" else "تنظیمات", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    }
                    Box(Modifier.size(44.dp).glass(CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Navigation, null, tint = Cyan) }
                }
                when (tab) {
                    0 -> HomeScreen(recording, paused, distance, speed, points, onStart = {
                        if (hasLocationPermission(context)) {
                            distance = 0.0; paused = false; recording = true
                            ContextCompat.startForegroundService(context, Intent(context, LocationTrackingService::class.java).setAction(LocationTrackingService.ACTION_START))
                        } else requestPermissions()
                    }, onPause = {
                        paused = !paused
                        context.startService(Intent(context, LocationTrackingService::class.java).setAction(if (paused) LocationTrackingService.ACTION_PAUSE else LocationTrackingService.ACTION_RESUME))
                    }, onStop = {
                        context.startService(Intent(context, LocationTrackingService::class.java).setAction(LocationTrackingService.ACTION_STOP))
                        recording = false; paused = false; routes = RouteStore.routes(context); points = emptyList(); distance = 0.0
                    })
                    1 -> HistoryScreen(routes) { routes = RouteStore.routes(context) }
                    else -> SettingsScreen(requestPermissions)
                }
                Spacer(Modifier.weight(1f))
                Row(Modifier.fillMaxWidth().padding(vertical = 12.dp).glass(RoundedCornerShape(28.dp)).padding(7.dp), horizontalArrangement = Arrangement.SpaceAround) {
                    NavItem("نقشه", Icons.Default.Map, tab == 0) { tab = 0 }
                    NavItem("تاریخچه", Icons.Default.History, tab == 1) { routes = RouteStore.routes(context); tab = 1 }
                    NavItem("تنظیمات", Icons.Default.Settings, tab == 2) { tab = 2 }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(recording: Boolean, paused: Boolean, distance: Double, speed: Float, points: List<TrackPoint>, onStart: () -> Unit, onPause: () -> Unit, onStop: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("مسافت", String.format(Locale.US, "%.2f km", distance / 1000), Icons.Default.Route, Modifier.weight(1f))
            StatCard("سرعت فعلی", String.format(Locale.US, "%.0f km/h", speed * 3.6), Icons.Default.Speed, Modifier.weight(1f))
        }
        Box(Modifier.fillMaxWidth().weight(1f, fill = false).heightIn(min = 250.dp, max = 330.dp).clip(RoundedCornerShape(28.dp)).border(1.dp, Color.White.copy(.13f), RoundedCornerShape(28.dp))) {
            RouteMap(points)
            Row(Modifier.align(Alignment.TopStart).padding(12.dp).glass(CircleShape).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(if (recording && !paused) Color(0xFF48E3A2) else Color.Gray, CircleShape))
                Spacer(Modifier.width(7.dp)); Text(if (!recording) "آماده ضبط" else if (paused) "ضبط متوقف شده" else "در حال ضبط", color = Color.White, fontSize = 12.sp)
            }
            Icon(Icons.Default.MyLocation, null, tint = Cyan, modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp).size(22.dp))
        }
        Box(Modifier.fillMaxWidth().glass(RoundedCornerShape(26.dp)).padding(18.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(if (recording) if (paused) "ضبط موقتاً متوقف است" else "مسیر شما در حال ثبت است" else "آماده‌ای برای کشف مسیرت؟", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(16.dp))
                if (!recording) {
                    Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Color(0xFF07111D))) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("شروع ضبط مسیر", fontWeight = FontWeight.Bold) }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = onPause, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Icon(if (paused) Icons.Default.PlayArrow else Icons.Default.Pause, null); Spacer(Modifier.width(5.dp)); Text(if (paused) "ادامه" else "مکث") }
                        Button(onClick = onStop, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF647C))) { Icon(Icons.Default.Stop, null); Spacer(Modifier.width(5.dp)); Text("پایان مسیر") }
                    }
                }
                Spacer(Modifier.height(8.dp)); Text("برای ثبت دقیق‌تر، دسترسی مکان و اعلان‌ها را فعال نگه دار", color = Color.White.copy(.48f), fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun RouteMap(points: List<TrackPoint>) {
    val context = LocalContext.current
    AndroidViewMap(points)
}

@Composable
fun AndroidViewMap(points: List<TrackPoint>) {
    val context = LocalContext.current
    androidx.compose.ui.viewinterop.AndroidView(factory = { ctx ->
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK); setMultiTouchControls(true)
            controller.setZoom(12.0); controller.setCenter(GeoPoint(40.4093, 49.8671))
        }
    }, update = { map ->
        map.overlays.removeAll { it is Polyline }
        if (points.isNotEmpty()) {
            val line = Polyline().apply { setPoints(points.map { GeoPoint(it.lat, it.lon) }); outlinePaint.strokeWidth = 9f; outlinePaint.color = android.graphics.Color.rgb(70, 190, 255) }
            map.overlays.add(line); map.controller.setCenter(GeoPoint(points.last().lat, points.last().lon)); map.controller.setZoom(16.0)
        }
        map.invalidate()
    }, modifier = Modifier.fillMaxSize())
}

@Composable
fun StatCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Column(modifier.glass(RoundedCornerShape(22.dp)).padding(15.dp)) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(20.dp)); Spacer(Modifier.height(10.dp))
        Text(value, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold); Text(label, color = Color.White.copy(.55f), fontSize = 11.sp)
    }
}

@Composable
fun HistoryScreen(routes: List<SavedRoute>, refresh: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("مسیرهای ذخیره‌شده", color = Color.White.copy(.6f), fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        if (routes.isEmpty()) Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Route, null, tint = Cyan, modifier = Modifier.size(44.dp)); Spacer(Modifier.height(12.dp)); Text("هنوز مسیری ثبت نشده", color = Color.White.copy(.7f)) } }
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(routes) { r ->
                Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(16.dp)) {
                    Text(SimpleDateFormat("yyyy/MM/dd  •  HH:mm", Locale.getDefault()).format(Date(r.started)), color = Color.White, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp)); Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                        Text(String.format(Locale.US, "%.2f km", r.distance / 1000), color = Cyan, fontWeight = FontWeight.Bold)
                        Text("${((r.ended-r.started)/60000).coerceAtLeast(0)} دقیقه", color = Color.White.copy(.65f))
                        Text("${r.points.size} نقطه", color = Color.White.copy(.5f))
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(requestPermissions: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("تنظیمات ضبط", color = Color.White.copy(.65f), fontSize = 13.sp)
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp)).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.LocationOn, null, tint = Cyan); Spacer(Modifier.width(10.dp)); Column { Text("دسترسی موقعیت مکانی", color = Color.White); Text("برای ثبت مسیر در پس‌زمینه لازم است", color = Color.White.copy(.5f), fontSize = 11.sp) } }
            Spacer(Modifier.height(14.dp)); Button(onClick = requestPermissions, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("درخواست مجوزهای GPS") }
        }
        Text("نکته: برای ضبط هنگام خاموش بودن صفحه، مجوز موقعیت مکانی «همیشه مجاز» را از تنظیمات اندروید فعال کن و محدودیت باتری برنامه را بردار.", color = Color.White.copy(.55f), fontSize = 12.sp, lineHeight = 19.sp)
        Text("اطلاعات مسیرها در حافظه محلی گوشی ذخیره می‌شود و به سرور ارسال نمی‌شود.", color = Color.White.copy(.55f), fontSize = 12.sp)
    }
}

@Composable
fun NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (selected) Cyan else Color.White.copy(.55f)); Text(label, color = if (selected) Cyan else Color.White.copy(.55f), fontSize = 10.sp)
    }
}

private fun Modifier.glass(shape: androidx.compose.ui.graphics.Shape): Modifier = this.clip(shape).background(Brush.linearGradient(listOf(Color.White.copy(.17f), Color.White.copy(.055f)))).border(1.dp, Brush.linearGradient(listOf(Color.White.copy(.35f), Color.White.copy(.07f))), shape)
private fun hasLocationPermission(context: Context) = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
