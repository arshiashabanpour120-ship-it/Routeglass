# RouteGlass

Android app source (Kotlin + Jetpack Compose) for GPS route recording, map display, and local route history.

## Build an APK with GitHub Actions (no AndroidIDE required)

1. Sign in to https://github.com/ or create an account.
2. Create a new repository. Give it a name such as `RouteGlass`. For the simplest setup, choose **Public** and do not initialize it with a README, .gitignore, or license.
3. On the new empty repository page, choose **uploading an existing file** (or **Add file → Upload files**).
4. Extract this ZIP on your phone or computer first. Open the extracted `RouteGlass` folder and upload **the contents inside it** (the `app` folder, `.github` folder, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, and other files). Do not upload the ZIP as a single file and do not upload an extra outer `RouteGlass` folder.
5. Commit the upload to the `main` branch.
6. Open the repository's **Actions** tab. Select **Build RouteGlass APK** on the left. If asked, enable GitHub Actions for the repository.
7. Open the newest run. Wait until it shows a green check mark and the build job succeeds.
8. Open that run, scroll to **Artifacts**, and download **RouteGlass-debug-APK**.
9. Extract the downloaded artifact ZIP. Inside it is `app-debug.apk`. Open it on your Android phone and allow installation from that source if Android asks.

The workflow uses JDK 17 and Gradle 8.9 and creates a debug APK. It does not require a signing key or AndroidIDE.

## Important notes

- This is a debug APK for personal testing, not a Play Store release build.
- The app requests location permissions and runs a location foreground service while recording. Android may require notification permission and appropriate location permission settings. For screen-off/background tracking, review the app's location and battery settings on the phone.
- GPS accuracy, background behavior, and map tile loading depend on the phone, Android version, location settings, network, and battery management. Test it outdoors before relying on it.
- The app stores route data locally on the device. Uninstalling the app or clearing its data may delete saved routes.
- The source has not been compiled or device-tested in this environment. If the GitHub build fails, open the failed workflow run and share the first actual error shown in the build log so it can be corrected.
